const { Pool } = require('pg');
const dotenv = require('dotenv');

dotenv.config();

const pool = new Pool({
    host: "localhost",
    user: "postgres",
    password: "postgres",
    database: 'auth', // Especifica aquí la base de datos auth
    port: process.env.DB_PORT || 5432 // Puerto de PostgreSQL, usualmente 5432
});

pool.connect((err, client, release) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to PostgreSQL');
    release();
});

module.exports = pool;
