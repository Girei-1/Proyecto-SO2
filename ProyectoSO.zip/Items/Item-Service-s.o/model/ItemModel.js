const { Client } = require('pg');  // Importar el cliente de PostgreSQL
const moment = require('moment-timezone');

// Configuración de la conexión a la base de datos
const client = new Client({
    host: 'localhost',
    port: 5432,        // Puerto por defecto de PostgreSQL
    user: 'postgres',      // Usuario de la base de datos
    password: 'postgres',      // Contraseña de la base de datos
    database: 'Item'  // Nombre de la base de datos
});

// Establecer la conexión
client.connect()
    .then(() => {
        console.log('Conexión exitosa a PostgreSQL');
    })
    .catch(err => {
        console.error('Error al conectar con PostgreSQL:', err.stack);
    });

// Definición del modelo Item
const Item = {
    getAll: (filters, callback) => {
        let query = 'SELECT * FROM item WHERE 1=1';
        let params = [];

        // Filtro por nombre
        if (filters.name) {
            query += ' AND name ILIKE $1';  // Usamos ILIKE para que sea case-insensitive
            params.push(`%${filters.name}%`);
        }

        // Filtro por rango de precio
        if (filters.minPrice) {
            query += ' AND price >= $2';
            params.push(filters.minPrice);
        }
        if (filters.maxPrice) {
            query += ' AND price <= $3';
            params.push(filters.maxPrice);
        }

        // Filtro por fechas de creación
        if (filters.startDate) {
            query += ' AND created_at >= $4';
            params.push(filters.startDate);
        }
        if (filters.endDate) {
            query += ' AND created_at <= $5';
            params.push(filters.endDate);
        }

        // Ordenar resultados
        if (filters.order) {
            query += ' ORDER BY ' + filters.order;
        }

        console.log('Ejecutando consulta:', query, params); // Para depuración

        // Ejecutamos la consulta con los parámetros
        client.query(query, params, (err, res) => {
            if (err) {
                callback(err);
            } else {
                callback(null, res.rows); // PostgreSQL devuelve los resultados en res.rows
            }
        });
    },

    getById: (id, callback) => {
        const query = 'SELECT * FROM item WHERE id = $1';
        client.query(query, [id], (err, res) => {
            if (err) {
                callback(err);
            } else {
                callback(null, res.rows[0]); // Devuelve el primer elemento
            }
        });
    },

    create: (data, callback) => {
        const { name, price, description, image_url } = data;
        const now = moment().tz('America/Argentina/Buenos_Aires').format('YYYY-MM-DD HH:mm:ss');

        // Consulta de inserción
        const query = `
            INSERT INTO item (name, price, description, image_url, created_at, modified_at) 
            VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`; // Retorna el registro insertado

        const params = [name, price, description, image_url, now, now];

        client.query(query, params, (err, res) => {
            if (err) {
                callback(err);
            } else {
                callback(null, res.rows[0]);  // Devuelve el item recién creado
            }
        });
    },

    update: (id, data, callback) => {
        const { name, price, description, image_url } = data;
        const now = moment().tz('America/Argentina/Buenos_Aires').format('YYYY-MM-DD HH:mm:ss');

        // Consulta de actualización
        const query = `
            UPDATE item SET name = $1, price = $2, description = $3, image_url = $4, modified_at = $5
            WHERE id = $6 RETURNING *`;

        const params = [name, price, description, image_url, now, id];

        client.query(query, params, (err, res) => {
            if (err) {
                callback(err);
            } else {
                callback(null, res.rows[0]); // Devuelve el item actualizado
            }
        });
    },

    delete: (id, callback) => {
        const query = 'DELETE FROM item WHERE id = $1 RETURNING *';  // Retorna el item eliminado
        client.query(query, [id], (err, res) => {
            if (err) {
                callback(err);
            } else {
                callback(null, res.rows[0]); // Devuelve el item eliminado
            }
        });
    },
};

module.exports = Item;
