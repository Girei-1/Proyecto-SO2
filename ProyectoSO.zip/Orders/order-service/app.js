// app.js o archivo principal
import express from 'express';
import orders from './Orders/Orders.js'; // Importa correctamente el router de Orders.js

const app = express();
app.use(express.json());//Para que procese el body



const PORT = 7000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});

console.log("app.js");
app.use("/api", orders);